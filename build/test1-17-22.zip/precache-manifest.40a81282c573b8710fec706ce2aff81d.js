self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "8a12dd5589b14afcfa6504522f22c89e",
    "url": "./index.html"
  },
  {
    "revision": "c9d11fa7a2cd55075bc0",
    "url": "./static/css/2.de424728.chunk.css"
  },
  {
    "revision": "d4b442e34d0e0a6c03b4",
    "url": "./static/css/main.31363b4d.chunk.css"
  },
  {
    "revision": "c9d11fa7a2cd55075bc0",
    "url": "./static/js/2.b8f2154c.chunk.js"
  },
  {
    "revision": "a3aa745604e919d4e60d",
    "url": "./static/js/3.97debe0e.chunk.js"
  },
  {
    "revision": "95f2477d78da00acdef6",
    "url": "./static/js/4.41b400bf.chunk.js"
  },
  {
    "revision": "d4b442e34d0e0a6c03b4",
    "url": "./static/js/main.43e7ac15.chunk.js"
  },
  {
    "revision": "b5c8670bc7b452f45c54",
    "url": "./static/js/runtime-main.a57bb9f1.js"
  },
  {
    "revision": "4b1178555c9601880573072d9b222a0b",
    "url": "./static/media/ATSE-2022.4b117855.pdf"
  },
  {
    "revision": "21f233e19402cc4a66866a7f31191f0d",
    "url": "./static/media/Agustina.21f233e1.woff"
  },
  {
    "revision": "4457817ac2b9993c65e81aa05828fe9c",
    "url": "./static/media/GoogleSans-Bold.4457817a.ttf"
  },
  {
    "revision": "90773b6158663ab0fe78b32680733677",
    "url": "./static/media/GoogleSans-BoldItalic.90773b61.ttf"
  },
  {
    "revision": "0ecddcdeccb7761ce899aa9ad9f0ac3f",
    "url": "./static/media/GoogleSans-Italic.0ecddcde.ttf"
  },
  {
    "revision": "8d57e4014b18edef070d285746485115",
    "url": "./static/media/GoogleSans-Medium.8d57e401.ttf"
  },
  {
    "revision": "8fd3737925e83c87d78a13700ccf9a62",
    "url": "./static/media/GoogleSans-MediumItalic.8fd37379.ttf"
  },
  {
    "revision": "b5c77a6aed75cdad9489effd0d5ea411",
    "url": "./static/media/GoogleSans-Regular.b5c77a6a.ttf"
  },
  {
    "revision": "ee6539921d713482b8ccd4d0d23961bb",
    "url": "./static/media/Montserrat-Regular.ee653992.ttf"
  },
  {
    "revision": "f29dcb7bd7f66018719b8192985b6325",
    "url": "./static/media/address_image.f29dcb7b.svg"
  },
  {
    "revision": "be4f4800caf3d342509c1af959ff434d",
    "url": "./static/media/animated_ashutosh.be4f4800.png"
  },
  {
    "revision": "dcd6dee2bd7458a4a576dc131506fd83",
    "url": "./static/media/animated_logo.dcd6dee2.svg"
  },
  {
    "revision": "9da59a7ac28c79cea3d353490bb6f06c",
    "url": "./static/media/announce.9da59a7a.svg"
  },
  {
    "revision": "fdbbd8cd4054b6386b72fa70a2216ee9",
    "url": "./static/media/biology.fdbbd8cd.svg"
  },
  {
    "revision": "058eca4cbdc03a1dad9a6bb943ac7831",
    "url": "./static/media/blogs_image.058eca4c.svg"
  },
  {
    "revision": "f4717779dadd116a83863c5f5028d6e3",
    "url": "./static/media/chemistry.f4717779.svg"
  },
  {
    "revision": "cacbc42b661f39344af81c631d8d36a9",
    "url": "./static/media/cloud_infrastructure.cacbc42b.svg"
  },
  {
    "revision": "fee92c18b1cfbd1faa704c51047f113d",
    "url": "./static/media/codeInLogo.fee92c18.png"
  },
  {
    "revision": "5f915405511f649dad433a6db9adbff4",
    "url": "./static/media/contactMail.5f915405.png"
  },
  {
    "revision": "ebf35d7f33ebbd4a4c6cff7e66e21fdb",
    "url": "./static/media/data_science.ebf35d7f.svg"
  },
  {
    "revision": "75a7107b7739a46950f66de29779eb52",
    "url": "./static/media/deeplearning_ai_logo.75a7107b.png"
  },
  {
    "revision": "3e23ca14e7a7c8a7b63d255466749000",
    "url": "./static/media/developerActivity.3e23ca14.svg"
  },
  {
    "revision": "16fd491d8b50b4d8b9e179fed0aa904b",
    "url": "./static/media/director.16fd491d.svg"
  },
  {
    "revision": "c1c9fea7323101eef57cabc4f77f4478",
    "url": "./static/media/doctors.c1c9fea7.svg"
  },
  {
    "revision": "63f707f224c8a842ac928c36e3be879a",
    "url": "./static/media/dsc_logo.63f707f2.png"
  },
  {
    "revision": "3bab7a9dc4324f1b2364d25a47fcfcf0",
    "url": "./static/media/education.3bab7a9d.svg"
  },
  {
    "revision": "fcff0bd417d2db453a4f7e9438bf0bac",
    "url": "./static/media/engineers.fcff0bd4.svg"
  },
  {
    "revision": "a00ede3f70759480e81f14f203edaa51",
    "url": "./static/media/experience.a00ede3f.svg"
  },
  {
    "revision": "0017cc6de3f72f67753efa37bb796fbd",
    "url": "./static/media/fa-brands-400.0017cc6d.svg"
  },
  {
    "revision": "06147b6cd88c7346cecd1edd060cd5de",
    "url": "./static/media/fa-brands-400.06147b6c.ttf"
  },
  {
    "revision": "5063b105c7646c8043d58c5289f02cca",
    "url": "./static/media/fa-brands-400.5063b105.eot"
  },
  {
    "revision": "c5e0f14f88a828261ba01558ce2bf26f",
    "url": "./static/media/fa-brands-400.c5e0f14f.woff"
  },
  {
    "revision": "cccc9d29470e879e40eb70249d9a2705",
    "url": "./static/media/fa-brands-400.cccc9d29.woff2"
  },
  {
    "revision": "65b286af947c0d982ca01b40e1fcab38",
    "url": "./static/media/fa-regular-400.65b286af.ttf"
  },
  {
    "revision": "c1a866ec0e04a5e1915b41fcf261457c",
    "url": "./static/media/fa-regular-400.c1a866ec.eot"
  },
  {
    "revision": "c4f508e7c4f01a9eeba7f08155cde04e",
    "url": "./static/media/fa-regular-400.c4f508e7.woff"
  },
  {
    "revision": "e647ddbb6d95cb01deac07ffafb2a085",
    "url": "./static/media/fa-regular-400.e647ddbb.svg"
  },
  {
    "revision": "f5f2566b93e89391da4db79462b8078b",
    "url": "./static/media/fa-regular-400.f5f2566b.woff2"
  },
  {
    "revision": "0bff33a5fd7ec390235476b4859747a0",
    "url": "./static/media/fa-solid-900.0bff33a5.ttf"
  },
  {
    "revision": "333bae208dc363746961b234ff6c2500",
    "url": "./static/media/fa-solid-900.333bae20.woff"
  },
  {
    "revision": "424c59fb1df79fcc3d0a41909c0192d2",
    "url": "./static/media/fa-solid-900.424c59fb.svg"
  },
  {
    "revision": "44d537ab79f921fde5a28b2c1636f397",
    "url": "./static/media/fa-solid-900.44d537ab.woff2"
  },
  {
    "revision": "8e4a6dcc692b3887f9f542cd6894d6d4",
    "url": "./static/media/fa-solid-900.8e4a6dcc.eot"
  },
  {
    "revision": "2936ce95f550e3feef7230ea543a4b60",
    "url": "./static/media/feelingProud.2936ce95.svg"
  },
  {
    "revision": "fce6080726685cabdb4f75a0d8018325",
    "url": "./static/media/fullstack.fce60807.svg"
  },
  {
    "revision": "0ee7e8c9444cdfefc10f6d86e18b9b5b",
    "url": "./static/media/gcp_logo.0ee7e8c9.png"
  },
  {
    "revision": "6eeb2e810d0fd9f3ca2dcd72de228e68",
    "url": "./static/media/github_logo.6eeb2e81.png"
  },
  {
    "revision": "0c8a4c114ad00f7854e91550379b9b91",
    "url": "./static/media/googleAssistant.0c8a4c11.jpg"
  },
  {
    "revision": "a6addc3fb6605480614b992ede8cd434",
    "url": "./static/media/googleAssistant.a6addc3f.svg"
  },
  {
    "revision": "d3fccbe1db76b96f4f320d9c0f7da30c",
    "url": "./static/media/ibm_logo.d3fccbe1.png"
  },
  {
    "revision": "571a8584e69ecfbe326c8b8385fbbf54",
    "url": "./static/media/iiitk_logo.571a8584.png"
  },
  {
    "revision": "29152cf756a1facead5393c32e373371",
    "url": "./static/media/intel_logo.29152cf7.jpg"
  },
  {
    "revision": "5b4a6449747ec61a6d9aa874f2a9ceba",
    "url": "./static/media/jsFramework.5b4a6449.svg"
  },
  {
    "revision": "c597fbded5de799dfb9abc3fc4f1c26f",
    "url": "./static/media/legato_logo.c597fbde.png"
  },
  {
    "revision": "7cbf2214604e5b85badf19b0511f915f",
    "url": "./static/media/logo.7cbf2214.png"
  },
  {
    "revision": "83ac24fb968a474c6a63f7a4e9a8f62c",
    "url": "./static/media/manOnTable.83ac24fb.svg"
  },
  {
    "revision": "069938a84edd6ebf383c318e9feb5d4c",
    "url": "./static/media/muffito_logo.069938a8.png"
  },
  {
    "revision": "95a12a2b8c3149cce2175679755c4b4d",
    "url": "./static/media/nptel_logo.95a12a2b.png"
  },
  {
    "revision": "6e89d065b4adb4ddec473d21520522c3",
    "url": "./static/media/physics.6e89d065.svg"
  },
  {
    "revision": "414dfbd98516b39255a3e22ed90b3f7d",
    "url": "./static/media/portfolio.414dfbd9.gif"
  },
  {
    "revision": "5faf790badc18fa9030f94836ece1df1",
    "url": "./static/media/programmer.5faf790b.svg"
  },
  {
    "revision": "b8ba948796d7ab532673c5ed2f315e74",
    "url": "./static/media/projects_image.b8ba9487.svg"
  },
  {
    "revision": "71408db71465afd742233e4a96f06526",
    "url": "./static/media/pwa.71408db7.png"
  },
  {
    "revision": "63f9388ef704db80e06afd5bcf60d5a2",
    "url": "./static/media/scholarship.63f9388e.svg"
  },
  {
    "revision": "f649c6ef3fa20ef98ab11dc93957468c",
    "url": "./static/media/signature.f649c6ef.png"
  },
  {
    "revision": "2c8611fc308579645dc96da510382932",
    "url": "./static/media/slider1.2c8611fc.svg"
  },
  {
    "revision": "2c497738be3831492aeb6bdc43f19154",
    "url": "./static/media/stanford_logo.2c497738.png"
  },
  {
    "revision": "6ac91b161c2c9934a44f72d75d18142d",
    "url": "./static/media/talksCardBack.6ac91b16.svg"
  },
  {
    "revision": "3fa5424232370e3d049c9555d9c440a4",
    "url": "./static/media/talksCardBackAlt.3fa54242.svg"
  },
  {
    "revision": "d63630893eb8cb64af65f395d393c481",
    "url": "./static/media/ui_ux_design.d6363089.svg"
  }
]);