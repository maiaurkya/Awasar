module.exports = {
  HOST: "localhost",
  USER: "newitzone_awasar_root",
  PASSWORD: "rM2vh2fL%L[*",
  DB: "newitzone_awasar"
};
