module.exports = {
  HOST: "mail.awasaredu.com",
  PORT: 465,
  AUTH: {
        	user: 'support@awasaredu.com',
        	pass: 'u(@QmfqrK&+W'
    	},
  FROM: "support@awasaredu.com"
};
